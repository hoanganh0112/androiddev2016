package vn.edu.zalo_usth.chatzalo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.ArrayAdapter;

import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;
import java.net.URISyntaxException;
import java.util.ArrayList;

import com.github.nkzawa.emitter.Emitter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    EditText edtUn;
    Button btnRegis, btnChat;
    ListView lvUsername, lvChat;

    ArrayList<String> arrayUsername;
    ArrayList<String> arrayChat;

    private Socket mSocket;
    {
        try {
            mSocket = IO.socket("http://192.168.0.25:3000");
        } catch (URISyntaxException e) {}
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSocket.connect();
        mSocket.on("result_regisUN", onNewMessage_regisUsername);
        mSocket.on("server-sent-username", onNewMessage_listUsername);
        mSocket.on("server-sent-chat", onNewMessage_listChat);

        arrayChat = new ArrayList<String>();
        edtUn = (EditText)findViewById(R.id.editTextUsername);
        btnRegis = (Button)findViewById(R.id.buttonRegister);
        btnRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSocket.emit("Client-sent-username", edtUn.getText().toString());
            }
        });

        btnChat = (Button)findViewById(R.id.buttonChat);
        btnChat.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mSocket.emit("client-sent-chat", edtUn.getText().toString());
            }
        });


    }

    private Emitter.Listener onNewMessage_regisUsername = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String noidung;
                    try {
                        noidung = data.getString("noidung");
                        if (noidung == "true"){
                            Toast.makeText(getApplicationContext(),"The registration is successful!",Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(getApplicationContext(),"The registration is failed!",Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

    private Emitter.Listener onNewMessage_listChat = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String noidung;
                    try {
                        noidung = data.getString("tinchat");

                        lvChat = (ListView)findViewById(R.id.listViewChat);

                        arrayChat.add(noidung);
                        ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayChat);
                        lvChat.setAdapter(adapter);


                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

    private Emitter.Listener onNewMessage_listUsername = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    JSONArray noidung;
                    try {
                        noidung = data.getJSONArray("danhsach");

                        lvUsername = (ListView) findViewById(R.id.listViewUsername);
                        arrayUsername = new ArrayList<String>();

                        for(int i=0; i<noidung.length(); i++){
                            arrayUsername.add( noidung.get(i).toString() );
                        }
                        ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayUsername);
                        lvUsername.setAdapter(adapter);

                            Toast.makeText(getApplicationContext(), noidung.length() + "", Toast.LENGTH_SHORT).show();
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

}

var express = require("express");
var app = express();
var server = require("http").createServer(app);
var io = require("socket.io").listen(server);
var fs = require("fs");
server.listen(process.env.PORT || 3000);

var arrayUsername = [];

app.get("/", function(req, res){
	res.sendFile(__dirname + "/index.html");	
});

io.sockets.on('connection', function (socket) {
	
  console.log("Some one has connected to Server!");
  
    socket.on('Client-sent-username', function (data) {

    	var result = false;
    	if (arrayUsername.indexOf(data) > -1){
    		result =false;
    	}else{
    		arrayUsername.push(data);
    		socket.un = data;
    		result = true;
    		io.sockets.emit('server-sent-username', { danhsach: arrayUsername });
    	}

    	socket.emit('result_regisUN', { noidung: result });
  });
  
    socket.on('client-sent-chat', function (chatcontent) {
    	io.sockets.emit('server-sent-chat', { tinchat: socket.un + ":" + chatcontent });
  });

});